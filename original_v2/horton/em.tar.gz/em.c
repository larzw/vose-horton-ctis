#include <stdio.h>
#include <stdlib.h>
#include <mkl.h>

/*
 *
 * def spmv(ptrn, val, vec, d, s, t, g_dim):

  print s
  sys.stdout.flush()

  results = np.zeros(shape=(s,1),dtype=float)
  #results = np.zeros(shape=s,dt0ype=int)

  if t==0:

    for i,r in enumerate(ptrn):

      results[r,0]+=val[i]*vec[0,0]

      for z in range(1,d):
        results[r+z,0]+=val[i]*vec[z,0]

      for a in range(1,d):
        for z in xrange(d):

          results[r+a*d+z+a*(g_dim-d),0]+=val[i]*vec[a*d+z,0]

  else:

    for i,r in enumerate(ptrn):

      results[0,0]+=val[i]*vec[r,0]

      for z in range(1,d):
        results[z,0]+=val[i]*vec[r+z,0]

      for a in range(1,d):
        for z in xrange(d):
          results[a*d+z,0]+=val[i]*vec[r+a*d+z+a*(g_dim-d),0]

  return results

*/



void spmv (long *ptrn, double *val, double *vec, long d, long size, long t, long g_dim, long nnz, double *results) {


  long i,z,a;

  for (i=0; i<size; i++) {
    results[i]=0.0;
  }

  // If not transpose
  if (t==0) {

    for (i=0; i<nnz; i++) {    

      long r=ptrn[i];

      results[r]+=val[i]*vec[0];

      for (z=1; z<d; z++) {
        results[r+z]+=val[i]*vec[z];
      }

      for (a=1; a<d; a++) {
        for (z=0; z<d; z++) {
      
          results[r+a*d+z+a*(g_dim-d)]+=val[i]*vec[a*d+z];

        }
      }

    }

  } else {

    for (i=0; i<nnz; i++) {    

      long r=ptrn[i];

      results[0]+=val[i]*vec[r];

      for (z=1; z<d; z++) {
        results[z]+=val[i]*vec[r+z];
      }

      for (a=1; a<d; a++) {
        for (z=0; z<d; z++) {
      
          results[a*d+z]+=val[i]*vec[r+a*d+z+a*(g_dim-d)];

        }
      }

    }

  }

}

void em (long *ptrn,double *val,double *f_initial,long d,long g_dim,long nnz,double *g,int iterations,double *f_final) {

  int i,j,k,m,n;

  double h_sum2,h_sum=0.0;

  double *g_estimate=(double*)malloc(g_dim*g_dim*sizeof(double));

  long t=0;

  long t0,t1,t2,t3,t4,t5,t6;

  double g_ratio;

  for (i=0; i<nnz; i++) {
    h_sum+=val[i];
  } 

  for (k=0; k<iterations; k++) {

    spmv (ptrn, val, f_initial, d, g_dim*g_dim, t, g_dim, nnz, g_estimate); 

    for (m=0; m<d; m++) {
      printf ("\n");
      for (n=0; n<d; n++) {
        printf ("%lf ",f_initial[m*d+n]);
      }
    }

    for (i=0; i<d*d; i++) {

      //printf ("%ld %ld %ld %ld %ld\n",(g_dim-d+1),i/d,i%d,(g_dim-d+1)*i/d,(g_dim-d+1)*i/d+i%d);

      h_sum2=0.0;

      t0=g_dim-d+1;
      t1=i/d;
      t2=i%d;
      t3=t0*t1;
      t4=t3+t2;

      //printf ("%ld %ld %ld %ld %ld\n",t0,t1,t2,t3,t4);
      //printf ("%ld\n",t4);

      for (j=0; j<nnz; j++) {

        if (g[ptrn[j]]==0.0 && g_estimate[ptrn[j]]==0.0) {
          g_ratio=1.0;
        }

        if (g[ptrn[j]]!=0.0 && g_estimate[ptrn[j]]==0.0) {
          g_ratio=1.1;
        }

        if (g_estimate[ptrn[j]]!=0.0) {
          g_ratio=g[ptrn[j]]/g_estimate[ptrn[j]];
        }

        h_sum2+=val[ptrn[j]+t4]*g_ratio;
      } 
      f_final[i]=(f_initial[i]/h_sum)*h_sum2;
    } 

    for (i=0; i<d*d; i++) {
      f_initial[i]=f_final[i];
    } 

  }  

}

int main (int argc, char **argv) {

  FILE* f1=fopen("g","r");
  FILE* f2=fopen("ptrn","r");
  FILE* f3=fopen("val","r");
  FILE* f4=fopen("g2","w");
  FILE* f5=fopen("h","r");

  int i;

  long g_dim=atol(argv[1]);
  long d=atol(argv[2]);
  long nnz=atol(argv[3]);
  int read_g=atoi(argv[4]);
  int print_debug=atoi(argv[5]);
  int return_column=atoi(argv[6]);
  int iterations=atoi(argv[7]);
  //int =atoi(argv[8]);

  double *g=(double*)malloc(g_dim*g_dim*sizeof(double));
  double *val=(double*)malloc(nnz*sizeof(double));
  long *ptrn=(long*)malloc(nnz*sizeof(long));

  //double *f_initial=(double*)malloc(d*d*sizeof(double));
  double *f_initial=(double*)calloc(d*d,sizeof(double));
  double *f_final=(double*)malloc(d*d*sizeof(double));
  //f[return_column]=1.0;

  srand(7);

  for (i=0; i<d*d; i++) {
    //f_initial[i]=(double)rand()/(double)RAND_MAX;
    f_initial[i]=2.0;
  }
  

  /*
  f_initial[0]=.9;
  f_initial[1]=.2;
  f_initial[2]=.1;
  f_initial[5]=.2;
  f_initial[6]=.1;
  f_initial[10]=.1;
  */


  double d0=1.0,d1=0.0,d2,d3;

  d2=d0/d1;

  d3=d2*d0;

  //printf ("%lf %lf\n",d2,d3);

  double *result=(double*)calloc(g_dim*g_dim,sizeof(double));


  
  if (read_g==1) {
    for (i=0; i<g_dim*g_dim; i++) {
      fscanf (f1,"%lf",&g[i]);
    }
  }    

  for (i=0; i<nnz; i++) {
    fscanf (f3,"%lf",&val[i]);
  }    

  for (i=0; i<nnz; i++) {
    fscanf (f2,"%d",&ptrn[i]);
  }    

  if (print_debug==1) {

    printf("%lf %lf\n",g[0],g[1]);
    printf("%lf %lf\n",val[0],val[1]);
    //printf("%lf %lf\n",f[0],f[1]);
    printf("%d %d\n",ptrn[0],ptrn[1]);

  }

  //spmv (ptrn, val, f, d, g_dim*g_dim, t, g_dim, nnz, result); 

  //for (i=0; i<g_dim*g_dim; i++) {
    //printf("%f\n",result[i]);
  //}    

    
  
  int n1=2;

  double alpha=1.0,beta=0.0;

  double *A=(double*)malloc(g_dim*g_dim*d*d*sizeof(double));

  //for (i=0; i<g_dim*g_dim*d*d; i++) {
    //fscanf (f5,"%lf",&A[i]);
  //}    

  double *X=(double*)calloc(d*d,sizeof(double));

  X[return_column]=1.0;

  for (i=0; i<d*d; i++) {
    X[i]=1.0;
  }

  double *Y=(double*)malloc(g_dim*g_dim*sizeof(double));

  int inc=1;
  
  

  //cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, n1, n1, n1, alpha, A, n1, B, n1, beta, C, n1);
  
  //cblas_dgemv(CblasRowMajor, CblasNoTrans, g_dim*g_dim, d*d, alpha, A, d*d, X, inc, beta, Y, inc);
  
  

  double t1=0.0,t2=0.0;

  //for (i=0; i<g_dim*g_dim; i++) {
    //t1+=(Y[i]-result[i])*(Y[i]-result[i]);
    //t2+=Y[i]*Y[i];
  //} 

  t1=sqrt(t1);
  t2=sqrt(t2);

  //printf("%lf %lf\n",t1,t2);

  long t=1;

  spmv (ptrn, val, g, d, d*d, t, g_dim, nnz, f_initial); 
  

  em (ptrn, val, f_initial, d, g_dim, nnz, g, iterations, f_final);

 



  return 0;

}

// MKL
//
// icc em.c -o em  -qopenmp -mkl=parallel -liomp5  -lpthread -lm -ldl -lrt
//
// ./em 17 5 9 1 0 0 1


